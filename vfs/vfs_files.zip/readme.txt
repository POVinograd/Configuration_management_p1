This is a test VFS with several files.
